(function(){
  const COLORS = { ATIVO:'#2E9E6D', AGUARDANDO_RETORNO:'#D98F2B', CANCELADO:'#CD171D', SEM_RASTREIO:'#9AA4AC', OUTRO:'#7A6FB0' };

  const STORE = 'windward-history';
  const EXPECTED_SHEET = 'Sheet0';
  const COL = { PROCESSO:0, PRODUTO:1, MASTER:24, STATUS:8, STATUS_TRACKING:149 };

  function localISODate(date = new Date()){
    const y = date.getFullYear();
    const m = String(date.getMonth()+1).padStart(2,'0');
    const d = String(date.getDate()).padStart(2,'0');
    return `${y}-${m}-${d}`;
  }
  let viewer = { role: 'viewer' };

  async function getViewer(){
    try { viewer = await SGLPages.me(); } catch (_) { viewer = { role: 'viewer' }; }
    const canManage = viewer.role === 'owner' || viewer.role === 'co_owner';
    const isLocalPreview = location.hostname === 'localhost' || location.hostname === '127.0.0.1';
    document.querySelector('.panel .upload-row').closest('.panel').style.display = canManage || isLocalPreview ? '' : 'none';
    clearBtn.style.display = canManage ? '' : 'none';
    return canManage;
  }

  const fileInput = document.getElementById('fileInput');
  const dropzone = document.getElementById('dropzone');
  const reportDate = document.getElementById('reportDate');
  const statusMsg = document.getElementById('statusMsg');
  const clearBtn = document.getElementById('clearBtn');

  reportDate.value = localISODate();

  ['dragover','dragenter'].forEach(ev => dropzone.addEventListener(ev, e => { e.preventDefault(); dropzone.classList.add('drag'); }));
  ['dragleave','drop'].forEach(ev => dropzone.addEventListener(ev, e => { e.preventDefault(); dropzone.classList.remove('drag'); }));
  dropzone.addEventListener('drop', e => {
    const f = e.dataTransfer.files && e.dataTransfer.files[0];
    if (f) handleFile(f);
  });
  fileInput.addEventListener('change', e => {
    const f = e.target.files && e.target.files[0];
    if (f) handleFile(f);
  });

  function normalize(s){ return (s || '').toString().trim().toLowerCase(); }

  function classifyStatus(raw){
    const norm = (raw || '').toString().trim().toUpperCase();
    if (norm === '') return 'SEM_RASTREIO';
    if (norm === 'ATIVO') return 'ATIVO';
    if (norm === 'AGUARDANDO RETORNO') return 'AGUARDANDO_RETORNO';
    if (norm === 'CANCELADO') return 'CANCELADO';
    if (norm.includes('ATIVO') && !norm.includes('CANCEL')) return 'ATIVO';
    if (norm.includes('AGUARD')) return 'AGUARDANDO_RETORNO';
    if (norm.includes('CANCEL')) return 'CANCELADO';
    return 'OUTRO';
  }

  function classifyProduto(raw){

  const produto =
    (raw || '')
      .toString()
      .trim()
      .toUpperCase();

  if (produto.includes('IMPORTAÇÃO MARÍTIMA')){
    return 'Importação Marítima';
  }

  if (produto.includes('EXPORTAÇÃO MARÍTIMA')){
    return 'Exportação Marítima';
  }

  return 'Outros';
}

  function emptyCounts(){
    return { total:0, ATIVO:0, AGUARDANDO_RETORNO:0, CANCELADO:0, SEM_RASTREIO:0, OUTRO:0 };
  }

  function handleFile(file){

  if (typeof XLSX === 'undefined'){
    setStatus(
      'A biblioteca de leitura Excel não está disponível.',
      'err'
    );
    return;
  }

  setStatus('Lendo ' + file.name + '…', '');

  const reader = new FileReader();

  reader.onload = function(e){

    try {

      const data = new Uint8Array(e.target.result);

      const wb = XLSX.read(data, {
        type: 'array',
        cellDates: true
      });

      if (!wb.SheetNames.includes(EXPECTED_SHEET)){
        throw new Error(
          'A aba esperada "' +
          EXPECTED_SHEET +
          '" não foi encontrada.'
        );
      }

      const sheet = wb.Sheets[EXPECTED_SHEET];

      const matrix = XLSX.utils.sheet_to_json(
        sheet,
        {
          header: 1,
          defval: '',
          raw: false
        }
      );

      if (matrix.length < 2){
        throw new Error(
          'A planilha não possui linhas de dados.'
        );
      }

      const headers =
        matrix[0].map(v =>
          String(v || '').trim()
        );

      const expectedHeaders = [
        [COL.PROCESSO, 'Processo'],
        [COL.PRODUTO, 'Produto'],
        [COL.MASTER, 'Master'],
        [COL.STATUS_TRACKING, 'Status Rastreio Tracking']
      ];

      const invalid =
        expectedHeaders.filter(
          ([idx,name]) => headers[idx] !== name
        );

      if (invalid.length){

        throw new Error(
          'Estrutura inválida da planilha. Colunas não encontradas: ' +
          invalid
            .map(([,name]) => name)
            .join(', ')
        );
      }

      const rows = matrix.slice(1);

      const counts = {
        ATIVO: 0,
        AGUARDANDO_RETORNO: 0,
        CANCELADO: 0,
        SEM_RASTREIO: 0,
        OUTRO: 0,
        COM_MASTER: 0
      };

      const produtos = {};

      const uniqueRows = [];

      const seen = new Set();

      rows.forEach(r => {

        const statusProcesso =
          String(
            r[COL.STATUS] || ''
          ).trim().toUpperCase();

        if (statusProcesso === 'CANCELADO'){
          return;
        }

        const processo =
          String(
            r[COL.PROCESSO] || ''
          ).trim();

        if (!processo){
          return;
        }

        if (seen.has(processo)){
          return;
        }

        seen.add(processo);

        uniqueRows.push(r);
      });

      uniqueRows.forEach(r => {

        const status =
          classifyStatus(
            r[COL.STATUS_TRACKING]
          );

        counts[status]++;

        if (
          (r[COL.MASTER] || '')
            .toString()
            .trim() !== ''
        ){
          counts.COM_MASTER++;
        }

        const produto =
          classifyProduto(
            r[COL.PRODUTO]
          );

        if (!produtos[produto]){
          produtos[produto] =
            emptyCounts();
        }

        produtos[produto].total++;

        produtos[produto][status]++;
      });

      const snapshot = {

        date:
          reportDate.value ||
          localISODate(),

        total:
          uniqueRows.length,

        counts:

        {
          ATIVO:
            counts.ATIVO,

          AGUARDANDO_RETORNO:
            counts.AGUARDANDO_RETORNO,

          CANCELADO:
            counts.CANCELADO,

          SEM_RASTREIO:
            counts.SEM_RASTREIO,

          OUTRO:
            counts.OUTRO,

          COM_MASTER:
            counts.COM_MASTER
        },

        produtos: {
  "Importação Marítima":
    produtos["Importação Marítima"] ||
    emptyCounts(),

  "Exportação Marítima":
    produtos["Exportação Marítima"] ||
    emptyCounts()
},

        importedAt:
          new Date().toISOString(),

        fileName:
          file.name,

        sheetName:
          EXPECTED_SHEET,

        layoutVersion:
          'windward-operacional-v1'
      };

      saveSnapshot(snapshot);

    }
    catch(err){

      setStatus(
        'Não consegui ler esse arquivo: ' +
        err.message,
        'err'
      );
    }
  };

  reader.onerror = function(){

    setStatus(
      'Falha ao ler o arquivo.',
      'err'
    );
  };

  reader.readAsArrayBuffer(file);
}

  function setStatus(msg, cls){
    statusMsg.textContent = msg;
    statusMsg.className = 'status-msg' + (cls ? ' ' + cls : '');
  }

  async function saveSnapshot(snapshot){
    try{
      const all = await SGLPages.read(STORE);
      const existing = all.find(r => r.date === snapshot.date);
      if (existing){
        const ok = confirm('Já existe um relatório salvo para ' + formatDate(snapshot.date) + '. Substituir pelos dados deste novo arquivo?');
        if (!ok){ setStatus('Importação cancelada. O histórico não foi alterado.', ''); return; }
        await SGLPages.patch(STORE, existing._id, snapshot);
      } else {
        await SGLPages.add(STORE, snapshot);
      }
      setStatus('Relatório de ' + formatDate(snapshot.date) + ' salvo e compartilhado — ' + snapshot.total + ' processos.', 'ok');
      fileInput.value = '';
      await renderAll();
    } catch(err){
      const detail = err && err.message ? err.message : 'falha desconhecida';
      setStatus('Erro ao salvar no histórico compartilhado: ' + detail, 'err');
    }
  }

  async function loadSnapshots(){
    try{
      const snaps = await SGLPages.read(STORE);
      return snaps.slice().sort((a,b) => String(a.date).localeCompare(String(b.date)));
    } catch(err){
      setStatus('O histórico compartilhado ainda não está disponível. O proprietário deve criar o arquivo dinâmico "' + STORE + '" na guia Data.', 'err');
      return [];
    }
  }

  function formatDate(iso){
    const parts = iso.split('-');
    return parts[2] + '/' + parts[1] + '/' + parts[0];
  }

  function aggregateSnapshots(snaps){
    const aggregate = {
      total: 0,
      counts: { ATIVO: 0, AGUARDANDO_RETORNO: 0, CANCELADO: 0, SEM_RASTREIO: 0, OUTRO: 0, COM_MASTER: 0 },
      produtos: {}
    };

    snaps.forEach(snapshot => {
      aggregate.total += snapshot.total || 0;

      Object.keys(aggregate.counts).forEach(key => {
        aggregate.counts[key] += snapshot.counts && snapshot.counts[key] || 0;
      });

      Object.entries(snapshot.produtos || {}).forEach(([name, produto]) => {
        if (!aggregate.produtos[name]) aggregate.produtos[name] = emptyCounts();
        aggregate.produtos[name].total += produto.total || 0;
        ['ATIVO', 'AGUARDANDO_RETORNO', 'CANCELADO', 'SEM_RASTREIO', 'OUTRO'].forEach(status => {
          aggregate.produtos[name][status] += produto[status] || 0;
        });
      });
    });

    return aggregate;
  }

  let chartInstance = null;

  async function renderAll(){
    const snaps = await loadSnapshots();
    const updatedDate = document.getElementById('updatedDate');
    const updatedSub = document.getElementById('updatedSub');

    if (!snaps.length){
      updatedDate.textContent = 'Nenhum relatório importado ainda';
      updatedSub.textContent = 'Envie a primeira exportação abaixo';
      document.getElementById('heroFrac').textContent = 'Importe um relatório para começar a acompanhar a ativação.';
      document.getElementById('deltaChipBox').innerHTML = '';
      setGauge(0);
      ['Total','Ativo','Aguardando','Cancelado','Outro','Master'].forEach(k => document.getElementById('kpi'+k).textContent = '–');
      document.getElementById('historyBody').innerHTML = '<tr><td colspan="7" style="color:var(--text-muted); text-align:center; padding:22px;">Nenhum histórico ainda</td></tr>';
      document.getElementById('produtoBox').innerHTML = '<div class="empty-state">Aparece assim que um relatório for importado.</div>';
      renderChart([]);
      return;
    }

    const latest = snaps[snaps.length - 1];
    const prev = snaps.length > 1 ? snaps[snaps.length - 2] : null;
    const aggregate = aggregateSnapshots(snaps);

    updatedDate.textContent = 'Atualizado em ' + formatDate(latest.date);
    updatedSub.textContent = aggregate.total + ' processos em todos os relatórios importados';

    const pct = aggregate.total ? (aggregate.counts.ATIVO / aggregate.total * 100) : 0;
    setGauge(pct);
    document.getElementById('heroFrac').innerHTML = '<b>' + aggregate.counts.ATIVO + '</b> de <b>' + aggregate.total + '</b> processos com rastreio ativo';

    const deltaBox = document.getElementById('deltaChipBox');
    if (prev){

  const saldo =
    (latest.counts.ATIVO || 0) -
    (prev.counts.ATIVO || 0);

  const cls =
    saldo > 0
      ? 'up'
      : saldo < 0
        ? 'down'
        : 'flat';

  const sinal =
    saldo > 0
      ? '+'
      : '';

  deltaBox.innerHTML =
    '<span class="delta-chip ' +
    cls +
    '">' +
    sinal +
    saldo +
    ' ativos em relação ao dia anterior' +
    '</span>';
}
    
    document.getElementById('kpiTotal').textContent = aggregate.total;
    document.getElementById('kpiAtivo').textContent = aggregate.counts.ATIVO;
    document.getElementById('kpiAguardando').textContent = aggregate.counts.AGUARDANDO_RETORNO;
    document.getElementById('kpiCancelado').textContent = aggregate.counts.CANCELADO;
    document.getElementById('kpiOutro').textContent = aggregate.counts.SEM_RASTREIO || 0;
    const masterCount = aggregate.counts.COM_MASTER || 0;
    const masterPct = aggregate.total ? (masterCount / aggregate.total * 100) : 0;
    document.getElementById('kpiMaster').textContent = masterCount + ' (' + masterPct.toFixed(1) + '%)';

    renderProdutos(aggregate);
    renderHistoryTable(snaps);
    renderChart(snaps);
  }

  function renderProdutos(latest){
    const box = document.getElementById('produtoBox');
    box.replaceChildren();
    const entries = Object.entries(latest.produtos || {}).map(([name,p]) => ({ name, ativo:p.ATIVO||0, total:p.total||0, pct:p.total ? (p.ATIVO/p.total*100) : 0 })).sort((a,b)=>b.total-a.total);
    if (!entries.length){ const e=document.createElement('div'); e.className='empty-state'; e.textContent='Nenhum dado de produto neste relatório.'; box.appendChild(e); return; }
    entries.forEach(e => {
      const row=document.createElement('div'); row.className='produto-row';
      const name=document.createElement('div'); name.className='produto-name'; name.textContent=e.name;
      const track=document.createElement('div'); track.className='produto-bar-track';
      const fill=document.createElement('div'); fill.className='produto-bar-fill'; fill.style.width=e.pct.toFixed(1)+'%'; track.appendChild(fill);
      const stats=document.createElement('div'); stats.className='produto-stats'; stats.textContent=e.ativo+' de '+e.total+' · '+e.pct.toFixed(1)+'%';
      row.append(name,track,stats); box.appendChild(row);
    });
  }

  function setGauge(pct){
    const circumference = 2 * Math.PI * 76;
    const clamped = Math.max(0, Math.min(100, pct));
    const offset = circumference * (1 - clamped / 100);
    const arc = document.getElementById('gaugeArc');
    arc.style.strokeDasharray = circumference.toFixed(1);
    arc.style.strokeDashoffset = offset.toFixed(1);
    document.getElementById('gaugePct').textContent = (pct ? pct.toFixed(1) : '0') + '%';
  }

  function renderHistoryTable(snaps){
    const body = document.getElementById('historyBody');
    const rows = snaps.slice().reverse().map(s => {
      return '<tr data-date="' + s.date + '">' +
        '<td>' + formatDate(s.date) + '</td>' +
        '<td class="num">' + s.total + '</td>' +
        '<td class="num" style="color:var(--ativo)">' + s.counts.ATIVO + '</td>' +
        '<td class="num" style="color:var(--aguardando)">' + s.counts.AGUARDANDO_RETORNO + '</td>' +
        '<td class="num" style="color:var(--cancelado)">' + s.counts.CANCELADO + '</td>' +
        '<td class="num" style="color:var(--sem)">' + s.counts.SEM_RASTREIO + '</td>' +
        '<td><span class="row-del" data-del="' + s.date + '" title="Remover esta data">✕</span></td>' +
      '</tr>';
    });
    body.innerHTML = rows.join('');
    body.querySelectorAll('[data-del]').forEach(el => {
      el.addEventListener('click', async () => {
        const date = el.getAttribute('data-del');
        try{
          if (!(viewer.role === 'owner' || viewer.role === 'co_owner')) return;
          const all = await SGLPages.read(STORE);
          const cur = all.find(r => r.date === date);
          if (cur && confirm('Remover definitivamente o histórico de ' + formatDate(date) + '?')) await SGLPages.remove(STORE, cur._id);
          await renderAll();
        } catch(e){}
      });
    });
  }

  function renderChart(snaps){
    const chartEmpty = document.getElementById('chartEmpty');
    const canvas = document.getElementById('trendChart');

    if (typeof Chart === 'undefined'){
      canvas.style.display = 'none';
      chartEmpty.style.display = 'block';
      chartEmpty.querySelector('div:last-child').textContent = 'A biblioteca do gráfico não carregou. Verifique sua conexão e recarregue a página.';
      return;
    }

    if (snaps.length < 2){
      canvas.style.display = 'none';
      chartEmpty.style.display = 'block';
      return;
    }
    canvas.style.display = 'block';
    chartEmpty.style.display = 'none';

    const labels = snaps.map(s => formatDate(s.date));
    const dataset = key => snaps.map(s => s.counts[key] || 0);

    if (chartInstance) chartInstance.destroy();
    chartInstance = new Chart(canvas.getContext('2d'), {
      type: 'line',
      data: {
        labels: labels,
        datasets: [
          { label: 'Ativo', data: dataset('ATIVO'), borderColor: COLORS.ATIVO, backgroundColor: 'rgba(46,158,109,0.13)', fill: true, tension: 0.3, pointRadius: 3 },
          { label: 'Aguardando retorno', data: dataset('AGUARDANDO_RETORNO'), borderColor: COLORS.AGUARDANDO_RETORNO, backgroundColor: 'transparent', fill: false, tension: 0.3, pointRadius: 3 },
          { label: 'Cancelado', data: dataset('CANCELADO'), borderColor: COLORS.CANCELADO, backgroundColor: 'transparent', fill: false, tension: 0.3, pointRadius: 3 }
        ]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: { legend: { display: false } },
        scales: {
          x: { grid: { color: 'rgba(20,20,20,0.06)' }, ticks: { color: '#83898D', font: { family: 'Arial', size: 11 } } },
          y: { beginAtZero: true, grid: { color: 'rgba(20,20,20,0.06)' }, ticks: { color: '#83898D', font: { family: 'Arial', size: 11 } } }
        }
      }
    });
  }

  clearBtn.addEventListener('click', async () => {
    if (!(viewer.role === 'owner' || viewer.role === 'co_owner')) return;
    if (!confirm('Isso removerá definitivamente todo o histórico compartilhado. Continuar?')) return;
    try{
      const records = await SGLPages.read(STORE);
      for (const record of records) await SGLPages.remove(STORE, record._id);
      setStatus('Histórico compartilhado limpo.', 'ok');
      await renderAll();
    } catch(e){ setStatus('Não consegui limpar o histórico compartilhado: ' + (e.message || e), 'err'); }
  });

  async function start(){
    await getViewer();
    await renderAll();
    SGLPages.autoRefresh(renderAll, 1);
  }
  start();
})();